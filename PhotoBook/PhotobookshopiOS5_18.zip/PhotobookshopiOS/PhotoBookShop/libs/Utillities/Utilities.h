//
//  Utilities.h
//  LeavesExamples
//
//  Created by Tom Brow on 4/19/10.
//  Copyright 2010 Tom Brow. All rights reserved.
//

#import <CoreGraphics/CoreGraphics.h>

CGAffineTransform aspectFit(CGRect innerRect, CGRect outerRect);
