//
//  PhotoCoverCell.h
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoBookCoverCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *coverImage;
@end
