//
//  PhotoCoverCell.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "PhotoBookCoverCell.h"

@implementation PhotoBookCoverCell

@end
