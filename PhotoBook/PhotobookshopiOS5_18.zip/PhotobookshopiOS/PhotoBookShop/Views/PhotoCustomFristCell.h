//
//  PhotoCustomFristCell.h
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoCustomFristCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageCustomFirst;

@end
