//
//  PhotoGalleryView.h
//  PhotoBookShop
//
//  Created by My Star on 5/1/16.
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>


@interface PhotoGalleryView:  UIView <UICollectionViewDataSource,UICollectionViewDelegate>

@end

