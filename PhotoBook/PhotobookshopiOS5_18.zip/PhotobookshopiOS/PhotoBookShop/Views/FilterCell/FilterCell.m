//
//  FilterCell.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "FilterCell.h"

@implementation FilterCell
-(id) initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    return self;
}
-(id) initWithCoder:(NSCoder *)aDecoder
{
    self =[super initWithCoder:aDecoder];
    return self;
}
-(id) init{
    self =[super init];
    return self;
}
@end
