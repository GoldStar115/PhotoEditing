//
//  PhotoCell.h
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageSelectedShow;
@property (weak, nonatomic) IBOutlet UIImageView *photoImage;
@end
