//
//  PhotoCell.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "PhotoCell.h"

@implementation PhotoCell

@end
