//
//  PhotoCustomFristCell.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "PhotoCustomFristCell.h"

@implementation PhotoCustomFristCell

@end
