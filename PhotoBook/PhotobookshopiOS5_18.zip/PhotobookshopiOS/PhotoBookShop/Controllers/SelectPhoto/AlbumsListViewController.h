//
//  AlbumsListViewController.h
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumsListViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tblAlbumList;

@end
