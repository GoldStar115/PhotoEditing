//
//  PhotoCustomViewController.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "PhotoCustomViewController.h"
#import "PhotoCustomCell.h"
#import "PhotoCoverCell.h"
#import "LXReorderableCollectionViewFlowLayout.h"
#import "PhotoEditController.h"
#import "ProfileInfo.h"
#import "ProductCategory.h"
#import "PhotoPreviewViewController.h"
#import "PhotoBookCoverViewController.h"
#import "PhotoCustomFristCell.h"
@interface PhotoCustomViewController ()<LXReorderableCollectionViewDelegateFlowLayout,LXReorderableCollectionViewDataSource>
{
    NSInteger countArray;

    UIImage *imageBackground;
    UIImage *imageFrontCover;
    Products *selectedProduct;
    UIImage *imageEndCover;
    NSMutableArray *arrMergeConstrant;
    NSArray *imgPointArr;
    UIImage *imgMerge;
}
@property UIImage *editedImage;
@end

@implementation PhotoCustomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    selectedProduct = [Profile instance].selectedProduct;
    self.photoCustomCollectionView.delegate = self;
    self.photoCustomCollectionView.dataSource =  self;
    countArray = [Profile instance].arrayCoverImages.count + 2;
    NSLog(@"CountArray = %d",(int)countArray);
}
- (void)makeCoverImage{
    imageEndCover = [UIImage imageNamed:@"black"];
    imageFrontCover = [UIImage imageNamed:@"white"];
    int index = 0;
    if ([Profile instance].arrFrontCoverPhotos.count  == 0) {
            for (index  = 0; index < 4 ; index ++) {
                [[Profile instance].arrFrontCoverPhotos addObject:[Profile instance].arrayCoverImages[index]];
            }
        [self.photoCoverCollectionView reloadData];
        [self.photoCustomCollectionView reloadData];
    }else{
        if ([Profile instance].isCoverEdited == true) {
            [Profile instance].isCoverEdited = false;
        }else{
            for (int indexFrontCover = 0; indexFrontCover < 4; indexFrontCover ++) {
                [[Profile instance].arrFrontCoverPhotos addObject:[Profile instance].arrayCoverImages[index]];
            }
        }     
        [self.photoCoverCollectionView reloadData];
        [self.photoCustomCollectionView reloadData];
    }
}
- (void)makeExpandArray{
    if ([Profile instance].arrExpandPhotos.count == 0) {
        for (int index = 0; index < countArray; index ++) {
            if (index == 0)
            {
                 [[Profile instance].arrExpandPhotos addObject:imageFrontCover];
            }
            else if(index == 1)
            {
               [[Profile instance].arrExpandPhotos addObject:[Profile instance].arrFrontCoverPhotos];
            }
            else{
                [[Profile instance].arrExpandPhotos addObject:[Profile instance].arrayCoverImages[index - 2]];
            }
        }
    }else{
        [Profile instance].arrExpandPhotos  = [NSMutableArray array];
        for (int index = 0; index < countArray; index ++) {
            if (index == 0)
            {
                [[Profile instance].arrExpandPhotos insertObject:imageFrontCover atIndex:index];
            }
            else if(index == 1)
            {
                [[Profile instance].arrExpandPhotos insertObject:[Profile instance].arrFrontCoverPhotos atIndex:index];
            }
            else{
                [[Profile instance].arrExpandPhotos insertObject:[Profile instance].arrayCoverImages[index - 2] atIndex:index];
            }
        }
    }
    [self.photoCoverCollectionView reloadData];
    [self.photoCustomCollectionView reloadData];
    arrMergeConstrant = [Profile instance].arrExpandPhotos;
    NSLog(@"ARRAT =  %@",arrMergeConstrant);
}
- (void)viewWillAppear:(BOOL)animated
{
    [self makeCoverImage];
    [self makeExpandArray];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Collection View Data Source
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if ([Profile instance].arrExpandPhotos.count > 0) {
        if (collectionView.tag == 0) {
            return  2;
        }else{
            return [Profile instance].arrExpandPhotos.count- 2;
        }
    }else{
        return 0;
    }
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView.tag == 0) {
        if (indexPath.row == 0) {
            PhotoCustomFristCell * cellFrist =(PhotoCustomFristCell*)[collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCustomFristCell" forIndexPath:indexPath];
            cellFrist.imageCustomFirst.image = imageFrontCover;
            return cellFrist;
        }
        else if(indexPath.row == 1){
            PhotoCoverCell *cellCover = (PhotoCoverCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCoverCell" forIndexPath:indexPath];
            NSMutableArray *tempArray = [NSMutableArray array];
            tempArray = [Profile instance].arrExpandPhotos[indexPath.row];
            cellCover.imageSubCover1.image = tempArray[0];
            cellCover.imageSubCover2.image = tempArray[1];
            cellCover.imageSubCover3.image = tempArray[2];
            cellCover.imageSubCover4.image = tempArray[3];
            [cellCover.btnFrontCover  setTitle:[Profile instance].coverTitle forState:UIControlStateNormal];
            return cellCover;
        }else{
            return nil;
        }
        
    }else {
   
        PhotoCustomCell * cell =(PhotoCustomCell*)[collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCustomCell" forIndexPath:indexPath];
        cell.imagePhotoCustom.image = [Profile instance].arrExpandPhotos[indexPath.row + 2];
        cell.lblSelectedImageTitle.text = [NSString stringWithFormat:@"%d",(int)indexPath.row];
        return cell;
    }
}
#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView.tag == 0) {
        if (indexPath.row == 0) {
            [self.photoCustomCollectionView reloadData];
            return;
        }
        else if (indexPath.row == 1)
        {
            [self.photoCustomCollectionView reloadData];
            PhotoBookCoverViewController *photoBookViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PhotoBookCoverViewController"];
            [self presentViewController:photoBookViewController animated:YES completion:nil];
        }
    }
    else
    {
     
        PhotoEditController *photoEditViewController  = [self.storyboard instantiateViewControllerWithIdentifier:@"PhotoEditController"];
        photoEditViewController.selectedIndex = indexPath.row;
        photoEditViewController.canvas_height = self.view.frame.size.width *0.7;
        photoEditViewController.canvas_width  = self.view.frame.size.width - 50;
        [self presentViewController:photoEditViewController animated:YES completion:nil];
    }

}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}
#pragma mark - UICollectionViewFlowLayoutDelegate
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(collectionView.frame.size.width/2 - 5, collectionView.frame.size.width/2 - 10);
}
#pragma mark - LXReorderableCollectionViewDataSource methods

- (void)collectionView:(UICollectionView *)collectionView itemAtIndexPath:(NSIndexPath *)fromIndexPath willMoveToIndexPath:(NSIndexPath *)toIndexPath {
    if (collectionView.tag == 1) {
        
        UIImage *tempImage = [Profile instance].arrExpandPhotos[fromIndexPath.item + 2];
        [[Profile instance].arrExpandPhotos removeObjectAtIndex:fromIndexPath.item + 2];
        [[Profile instance].arrExpandPhotos insertObject:tempImage atIndex:toIndexPath.item + 2];
        NSLog(@"FromIndex = %d || ToIndex = %d",(int)fromIndexPath.item,(int)toIndexPath.item);
         UIImage *tempImage1 = [Profile instance].arrayCoverImages[fromIndexPath.item ];
        [[Profile instance].arrayCoverImages removeObjectAtIndex:fromIndexPath.item];
        [[Profile instance].arrayCoverImages insertObject:tempImage1 atIndex:toIndexPath.item ];
    }
    
}

- (BOOL)collectionView:(UICollectionView *)collectionView canMoveItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView.tag == 1) {
        return YES;
    }
    return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView itemAtIndexPath:(NSIndexPath *)fromIndexPath canMoveToIndexPath:(NSIndexPath *)toIndexPath {
    if (collectionView.tag == 1) {
        return YES;
    }
    return NO;
}

#pragma mark - LXReorderableCollectionViewDelegateFlowLayout methods

- (void)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout willBeginDraggingItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView.tag == 1) {
        NSLog(@"will begin drag");
    }
}

- (void)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout didBeginDraggingItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"did begin drag");
}

- (void)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout willEndDraggingItemAtIndexPath:(NSIndexPath *)indexPath {
        if (collectionView.tag == 1) {
    NSLog(@"will end drag");
        }
}

- (void)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout didEndDraggingItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView.tag == 1) {
        NSLog(@"did end drag");
        [self onUpdateFrontCoverImage];
        [self.photoCoverCollectionView reloadData];
        [self.photoCustomCollectionView reloadData];
    }

}

#pragma mark- UpdateFrontCover
- (void)onUpdateFrontCoverImage{
    if ([Profile instance].arrExpandPhotos[2]) {
        [[Profile instance].arrFrontCoverPhotos insertObject:[Profile instance].arrExpandPhotos[2] atIndex:0];
    }else{
        [[Profile instance].arrFrontCoverPhotos insertObject:imageFrontCover atIndex:0];
    }
    if ([Profile instance].arrExpandPhotos[3]) {
        [[Profile instance].arrFrontCoverPhotos insertObject:[Profile instance].arrExpandPhotos[3] atIndex:1];
    }else{
        [[Profile instance].arrFrontCoverPhotos insertObject:imageFrontCover atIndex:1];
    }
    if ([Profile instance].arrExpandPhotos[4]) {
        [[Profile instance].arrFrontCoverPhotos insertObject:[Profile instance].arrExpandPhotos[4] atIndex:2];
    }else{
        [[Profile instance].arrFrontCoverPhotos insertObject:imageFrontCover atIndex:2];
    }
    if ([Profile instance].arrExpandPhotos[5]) {
        [[Profile instance].arrFrontCoverPhotos insertObject:[Profile instance].arrExpandPhotos[5] atIndex:3];
    }else{
        [[Profile instance].arrFrontCoverPhotos insertObject:imageFrontCover atIndex:3];
    }
    [self.photoCoverCollectionView reloadData];
    [self.photoCustomCollectionView reloadData];
//    BOOL suc = [self mergedImageOnMainImage:[UIImage imageNamed:@"facebook.png"] WithImageArray:[Profile instance].arrFrontCoverPhotos AndImagePointArray:nil];
    
//    if (suc == YES) {
//        NSLog(@"Images Successfully Mearged & Saved to Album");
//    }
//    else {
//        NSLog(@"Images not Mearged & not Saved to Album");
//    }
}

#pragma mark- ImageMerge
- (BOOL) mergedImageOnMainImage:(UIImage *)mainImg WithImageArray:(NSArray *)imgArray AndImagePointArray:(NSArray *)imgPointArray
{
    
    UIGraphicsBeginImageContext(mainImg.size);
    
    [mainImg drawInRect:CGRectMake(0, 0, mainImg.size.width, mainImg.size.height)];
    int i = 0;
    for (UIImage *img in imgArray) {
        [img drawInRect:CGRectMake([[imgPointArray objectAtIndex:i] floatValue],
                                   [[imgPointArray objectAtIndex:i+1] floatValue],
                                   img.size.width,
                                   img.size.height)];
        
        i+=2;
    }
    
    CGImageRef NewMergeImg = CGImageCreateWithImageInRect(UIGraphicsGetImageFromCurrentImageContext().CGImage,
                                                          CGRectMake(0, 0, mainImg.size.width, mainImg.size.height));
    
    UIGraphicsEndImageContext();
    
    
    if (NewMergeImg == nil) {
        return NO;
    }
    else {
        UIImageWriteToSavedPhotosAlbum([UIImage imageWithCGImage:NewMergeImg], self, nil, nil);
        imgMerge = [UIImage imageWithCGImage:NewMergeImg];
        return YES;
    }
}

#pragma mark-  onBack
- (IBAction)onBack:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark- onPreview
- (IBAction)onPreView:(id)sender {
    PhotoPreviewViewController *previewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PhotoPreviewViewController"];
    [self presentViewController:previewController animated:YES completion:nil];
}

#pragma mark - setCanvasSize
-(float) setCanvasSize
{
    int product_width  = [selectedProduct.width intValue];
    int product_height = [selectedProduct.height intValue];
    double ratio=1.0;
    if(product_height >product_width)    {
        ratio =(product_width*1.0) /(product_height*1.0);
        return ratio;
    }else{
        ratio =(product_height*1.0) /(product_width*1.0);
        return ratio;
    }
    
}

@end
