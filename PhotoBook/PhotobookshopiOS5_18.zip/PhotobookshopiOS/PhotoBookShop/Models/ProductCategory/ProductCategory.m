//
//  ProductCategory.m
//  PhotoBookShop
//  Copyright © 2016 Peter. All rights reserved.
//

#import "ProductCategory.h"

@implementation ProductCategory

@end

@implementation CategoryFormats

@end

@implementation ProductCategorySpecification

@end

@implementation Products

@end